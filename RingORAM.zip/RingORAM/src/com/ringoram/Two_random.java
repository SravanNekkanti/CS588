package com.ringoram;

public class Two_random {
	int random;
	int no;
}
