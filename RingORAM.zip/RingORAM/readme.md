*A simple implementation of paper "Constants Count: Practical Improvements to Oblivious RAM", 
*Ring ORAM proposed by Ling Ren et al., without encryption.

*Need jar package "guava-19.0.jar".

*First run class "Server" in package com.server, then run calss "Client" in package com.Client.

*The tree store in server storage is full binary tree.
